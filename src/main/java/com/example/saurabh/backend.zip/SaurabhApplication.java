package com.example.saurabh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaurabhApplication {

	public static void main(String[] args) {
		SpringApplication.run(SaurabhApplication.class, args);
	}

}
