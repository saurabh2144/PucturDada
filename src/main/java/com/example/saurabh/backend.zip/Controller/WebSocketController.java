package com.example.saurabh.Controller;


import com.example.saurabh.entity.Message;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;

@Controller
public class WebSocketController {

    //initial friend request
    @MessageMapping("/message")
    @SendTo("/topic/response")
    public Message handleFriendRequest(Message message) {
     
        System.out.println("Friend request message received: " + message);
        
        
        return  message;
    }

    //accept/reject notification
    @MessageMapping("/notification")
    @SendTo("/topic/getnoti")
    public Message handleNotification(Message message) {
       
        System.out.println("Notification message received: " + message);
          
        
        
        
    
        return message;
    }
}
