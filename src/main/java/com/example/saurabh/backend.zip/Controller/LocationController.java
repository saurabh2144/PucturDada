package com.example.saurabh.Controller;

import com.example.saurabh.entity.Mechanic;
import com.example.saurabh.entity.MechanicRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
public class LocationController {
	
	 @Autowired
	    private MechanicRepository mecaRepository;

	@GetMapping("/show-location")
	public String showLocation() {
		
		//ye return karega simple html file jisme sare mechanic dikhenge
		return "AllLocFile"; 
	}
    //phle hum log yahi location manually de rhe the frontend ko jaiesa ki normal book file me dekh sakte hai
	//iske upar wale method me model as prameter pass karte the fir model.addatrribute =>
	// model.addAttribute("latitude1", latitude1);
	//model.addAttribute("longitude1", longitude1);aiese bhejte the backend se manually
	//aur frontend me kai var me store karte the fetch karte the  var Driver1Lat = [[${latitude1}]];// driver1 location
   //getmechnics ab backend se data bhejega front end ko database me se nilkaal ke
	//ye niche wala meyhod bhejega list me user ka data jo ki json me jayega
	//aur frontend fetch('/getMechanics').then(response => response.json()) se data fetch karega 
	
	@GetMapping("/getMechanics")
    @ResponseBody
    public List<Mechanic> getMechanics() {
        return  mecaRepository.findAll();
      
    }
	 
	@GetMapping("/getNearestMechanic")
	@ResponseBody
	public Mechanic getsinglemecname() {
		   Mechanic mechanic = mecaRepository.findByName("mohit");
		return mechanic;
		
	}
	
	
	//===============================================
	
	//ab mechnaic page ke liye direction denge 
	
	
	 // Show form for adding a mechanic(bas samjhne ke liye hai niche wala)
	//ye emty model bhejega aur usme ek key "mechanic" aurvalue me mechanic khali object from mechanic entity se
	
    @GetMapping("/addMechanic") 
    public String showAddForm(Model model) {
        model.addAttribute("mechanic", new Mechanic());
        
        return "AddMechanic";
        
    }
  //jioo ki object ka har paramter ek input box se connect ho jayega aur waha se la ke database me save kar dega like
  	// mechnaic m = new mechanic(); fir m.setlatitude kar rhe the manually deatil set kar rhe the
    //yaha form se db me save kar rhe db
    @PostMapping("/addMechanic")
    public String addMechanic(@ModelAttribute Mechanic mechanic) {
        mecaRepository.save(mechanic);
      
	      
     
        return "redirect:/MechanicPage"; 
        
    }
    
    
    //for login page 
    @GetMapping("/loginmec")
    public String showLoginForm(Model model) {
        model.addAttribute("login", new Mechanic()); //khaali mechanic jo ja k chhipak jayega
        return "logy"; 
    }

    
    @PostMapping("/loginmec")
    public String handleLogin(@ModelAttribute("login") Mechanic mechanic, Model model) {
        //databse se mechanic object uthaa ke laa rhe 
        Mechanic existingMechanic = mecaRepository.findByName(mechanic.getName());
        
        if (existingMechanic != null && existingMechanic.getPassword().equals(mechanic.getPassword())) {
            // Login success
            return "redirect:/sec"; 
        } else {
            // Login failed
            model.addAttribute("error", "Invalid username or password");
            return "logy";
        }
    }

    @PostMapping("/paymentSuccess")
    public ResponseEntity<String> paymentSuccess(@RequestParam String paymentId) {
        System.out.println("Payment Successful: " + paymentId);
        return ResponseEntity.ok("Payment Received Successfully!");
    }

    

    @GetMapping("/sec")
	public String Showhomee(){
		return "Second";
		
	}
    
    @GetMapping("/loginuser")
    public String loguser() {
    	return "ulo";
    }
 
	
	
	
	@GetMapping("/")
	public String Showhome() {
		return "Index";
		
	}
}