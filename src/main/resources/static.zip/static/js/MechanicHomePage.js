var stompClient = null;

  function connect() {
    const socket = new SockJS("/google");
    stompClient = Stomp.over(socket);

    stompClient.connect({}, (frame) => {
      console.log("Connected: " + frame);
      stompClient.subscribe("/topic/response", (message) => {
        const response = JSON.parse(message.body);
        const displayMessage = response.message || "No message received";
        $("#messages").append(`<p>${displayMessage}</p>`);
        $("#popupOverlay").show();
        $("#pp").fadeIn();
      });
    }, (error) => {
      console.error("Connection error: ", error);
      alert("Failed to connect to the WebSocket. Please try again later.");
    });
  }

  function sendFriendRequest() {
    if (stompClient && stompClient.connected) {
      const message = {
        name: "User123",
        message: "Mohit accepted your request"
      };
      stompClient.send("/app/notification", {}, JSON.stringify(message));
      alert("Please reach as soon as possible");
    } else {
      alert("Unable to send request. Please check the connection.");
    }
  }

  function initMap() {
    const map = L.map('map').setView([0, 0], 14);
    fetch('/getNearestMechanic')
      .then(response => response.json())
      .then(mechanic => {
        if (mechanic) {
          const mechanicLat = mechanic.latitude;
          const mechanicLon = mechanic.longitude;

          L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
            attribution: '&copy; OpenStreetMap contributors'
          }).addTo(map);

          L.marker([mechanicLat, mechanicLon], {
            title: mechanic.name,
            icon: L.icon({
              iconUrl: 'https://cdn-icons-png.flaticon.com/512/2972/2972185.png',
              iconSize: [50, 50]
            })
          }).addTo(map).bindPopup(`<strong>${mechanic.name}</strong>`);

          if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(position => {
              const userLat = position.coords.latitude;
              const userLon = position.coords.longitude;

              L.marker([userLat, userLon], {
                title: "Your Location",
                icon: L.icon({
                  iconUrl: 'https://cdn-icons-png.flaticon.com/512/7124/7124723.png',
                  iconSize: [40, 40]
                })
              }).addTo(map);

              map.fitBounds([
                [userLat, userLon],
                [mechanicLat, mechanicLon]
              ]);

              L.Routing.control({
                waypoints: [
                  L.latLng(mechanicLat, mechanicLon),
                  L.latLng(userLat, userLon)
                ],
                routeWhileDragging: false,
                addWaypoints: false
              }).addTo(map);
            });
          } else {
            alert("Geolocation is not supported by this browser.");
          }
        } else {
          alert("No mechanic found.");
        }
      })
      .catch(error => console.error('Error fetching mechanic:', error));
  }

  $(document).ready(() => {
    connect();

    $("#acceptBtn").click(() => {
      $(".map-container").show();
      $("#popupOverlay").hide();
      $("#pp").hide();
      sendFriendRequest();
      initMap();
    });

    $("#rejectBtn").click(() => {
      $("#popupOverlay").hide();
      $("#pp").hide();
      alert("Request Rejected");
    });
  });

  window.onbeforeunload = () => {
    if (stompClient && stompClient.connected) {
      stompClient.disconnect();
      console.log("Disconnected");
    }
  };